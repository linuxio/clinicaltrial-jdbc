package com.apps.semanticbits.clinicaltrial.service;

import java.util.List;

import com.apps.semanticbits.clinicaltrial.service.domain.ClinicalTrial;

public interface ClinicalTrialService {
    public List<ClinicalTrial>  getClinicalTrial();
}
