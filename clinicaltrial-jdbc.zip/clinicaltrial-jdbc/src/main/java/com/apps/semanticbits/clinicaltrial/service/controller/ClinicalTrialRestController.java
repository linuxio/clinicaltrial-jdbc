package com.apps.semanticbits.clinicaltrial.service.controller;

import java.util.List;

import com.apps.semanticbits.clinicaltrial.service.domain.ClinicalTrial;
import com.apps.semanticbits.clinicaltrial.service.ClinicalTrialService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Named;
import javax.annotation.Resource;

@RestController
@RequestMapping("/ct")
public class ClinicalTrialRestController {

    @Autowired
    ClinicalTrialService clinicalTrialService;

    private Logger logger=LoggerFactory.getLogger(ClinicalTrialRestController.class);


    @RequestMapping(value = "/clinicalTrial",method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<ClinicalTrial>  getClinicalTrial() {
        logger.info("GET ClinicalTrial list ");
        return clinicalTrialService.getClinicalTrial();
    }

}
