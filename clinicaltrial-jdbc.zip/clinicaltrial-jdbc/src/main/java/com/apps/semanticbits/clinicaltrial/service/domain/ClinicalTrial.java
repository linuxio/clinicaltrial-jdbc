package com.apps.semanticbits.clinicaltrial.service.domain;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author sreenn1
 */
@Entity
@Table(name = "clinical_trial")
public class ClinicalTrial implements Serializable {

    private static final long serialVersionUID = 1L;
    @Size(max = 200)
    @Column(name = "nct_id")
    private String nctId;
    @Size(max = 4000)
    @Column(name = "official_title")
    private String officialTitle;
    @Size(max = 50)
    @Column(name = "phase")
    private String phase;
    @Column(name = "primary_completion_date")
    @Temporal(TemporalType.DATE)
    private Date primaryCompletionDate;

    public ClinicalTrial() {
    }

    public ClinicalTrial(String nctId, String officialTitle, String phase, Date primaryCompletionDate) {
        this.nctId = nctId;
        this.officialTitle = officialTitle;
        this.phase = phase;
        this.primaryCompletionDate = primaryCompletionDate;
    }

    
    public String getNctId() {
        return nctId;
    }

    public void setNctId(String nctId) {
        this.nctId = nctId;
    }

    public String getOfficialTitle() {
        return officialTitle;
    }

    public void setOfficialTitle(String officialTitle) {
        this.officialTitle = officialTitle;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(String phase) {
        this.phase = phase;
    }

    public Date getPrimaryCompletionDate() {
        return primaryCompletionDate;
    }

    public void setPrimaryCompletionDate(Date primaryCompletionDate) {
        this.primaryCompletionDate = primaryCompletionDate;
    }

    
}
