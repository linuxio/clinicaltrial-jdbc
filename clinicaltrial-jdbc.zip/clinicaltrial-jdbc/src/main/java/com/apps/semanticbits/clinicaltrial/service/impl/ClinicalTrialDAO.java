package com.apps.semanticbits.clinicaltrial.service.impl;

import java.sql.*;

import com.apps.semanticbits.clinicaltrial.service.domain.ClinicalTrial;

import java.util.ArrayList;
import java.util.List;



public class ClinicalTrialDAO {
 static final String JDBC_DRIVER = "org.postgresql.Driver";  
 static final String DB_URL = "jdbc:postgresql://localhost:5432/postgres";
 static final String USER = "postgres";
 static final String PASS = "postgres";
 
 public List<ClinicalTrial>  getClinicalTrial(){

	 Connection conn = null;
	 Statement stmt = null;
	 List<ClinicalTrial> clinicalTrialList = new ArrayList<ClinicalTrial>();

	 try{
	    Class.forName(JDBC_DRIVER);
	    conn = DriverManager.getConnection(DB_URL,USER,PASS);
	    stmt = conn.createStatement();
	    String sql;
	    sql = "SELECT nct_id, official_title, phase, primary_completion_date  FROM clinical_trial;";
	    ResultSet rs = stmt.executeQuery(sql);

	    while(rs.next()){
	    	ClinicalTrial clinicalTrial = new ClinicalTrial();
	    	clinicalTrial.setNctId(rs.getString("nct_id"));
	    	clinicalTrial.setOfficialTitle(rs.getString("official_title"));
	    	clinicalTrial.setPhase(rs.getString("phase"));
	    	clinicalTrial.setPrimaryCompletionDate(rs.getDate(4));
	    	clinicalTrialList.add(clinicalTrial);
	    }
	    rs.close();
	    stmt.close();
	    conn.close();
	 }catch(SQLException se){
	    se.printStackTrace();
	 }catch(Exception e){
	    e.printStackTrace();
	 }finally{
	    try{
	       if(stmt!=null)
	          stmt.close();
	    }catch(SQLException se2){
	    }
	    try{
	       if(conn!=null)
	          conn.close();
	    }catch(SQLException se){
	       se.printStackTrace();
	    }
	 }
	 return clinicalTrialList;
 }

}//end ClinicalTrialDAO