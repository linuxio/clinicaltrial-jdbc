package com.apps.semanticbits.clinicaltrial.service.impl;

import com.apps.semanticbits.clinicaltrial.service.ClinicalTrialService;
import com.apps.semanticbits.clinicaltrial.service.domain.ClinicalTrial;

import org.springframework.stereotype.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.json.JSONArray;


@Service("clinicalTrialService")
public class ClinicalTrialServiceImpl implements ClinicalTrialService{

    private static Logger logger= LoggerFactory.getLogger(ClinicalTrialServiceImpl.class);
    private ClinicalTrialDAO ctDao = new ClinicalTrialDAO();

   
    public List<ClinicalTrial>  getClinicalTrial(){
    	return ctDao.getClinicalTrial();
    }
}


