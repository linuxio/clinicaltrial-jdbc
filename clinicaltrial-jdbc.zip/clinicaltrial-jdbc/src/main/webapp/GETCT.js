	var app = angular.module('formSubmit', []);
	
	app.controller('FormSubmitController',[ '$scope', '$http', function($scope, $http) {
			
		$scope.list = [];
			$scope.headerText = 'SemanticBits Clinical Trial List Display ';
			$scope.submit = function() {
				
				var response = $http.get('http://localhost:8080/clinicaltrial-jdbc/rest/ct/clinicalTrial');
				response.success(function(data, status, headers, config) {
					$scope.list = data;
					$scope.colNames = Object.keys($scope.list[0])
				});
				response.error(function(data, status, headers, config) {
					alert( "Exception details: " + JSON.stringify({data: data}));
				});
				
				//Empty list data after process
				//$scope.list = [];
				
			};
			$scope.submit();
		}]);

	
