package com.apps.semanticbits.clinicaltrial.service.controller;



import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;

import org.json.JSONObject;
import org.json.JSONArray;



public class TestRestService extends BaseWebApplicationContextTests {

    @Test
    public void testGetClinicalTrials() throws Exception {
        request.setMethod("GET");
        request.addHeader("Accept", "application/json");
        request.addHeader("Content-Type", "application/xml");
        request.setRequestURI("/ct/clinicalTrial");
        request.setContentType("application/xml");
        request.setMethod("GET");
System.out.println(request.getRequestURI());
System.out.println(request.getRequestURL());
        servlet.service(request, response);
        String result = response.getContentAsString();
        Assert.assertNotNull(result);
    }



}
